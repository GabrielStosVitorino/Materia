
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Numero {

    public static void main(String[] args) {

        System.out.println("Coloque um número de 0 a 10: ");
        Scanner leitor = new Scanner(System.in);
        Integer valorDigitado = leitor.nextInt();

        while (valorDigitado <= 0 || valorDigitado >= 10) {
            System.out.println("Digite um número válido");
            valorDigitado = leitor.nextInt();
        }
        System.out.println("ok");

        Integer numeroSorteado = ThreadLocalRandom.current().nextInt(0, 11);
        Integer contador = 0;
        while (numeroSorteado != valorDigitado) {
            System.out.println("Número errado, o número era " + numeroSorteado);
            System.out.println("Digite outro");
            valorDigitado = leitor.nextInt();
            numeroSorteado = ThreadLocalRandom.current().nextInt(0, 11);
            contador++;
            if (valorDigitado >= 0 || valorDigitado <= 10) {
                if (contador <= 3) {
                    System.out.println("Você é muito sortudo");
                } else if (contador >= 4 && contador <= 10) {
                    System.out.println("Você é sortudo");
                } else {
                    System.out.println("É melhor você parar de apostar e ir trabalhar");
                }
            } else {
                System.out.println("Digite um número válido");
            }
        }

    }
}
