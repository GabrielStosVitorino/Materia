
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Sorteio {

    public static void main(String[] args) {

        Scanner sorte = new Scanner(System.in);

        Integer par = 0;
        Integer impar = 0;
        Integer sorteio = 0;

        System.out.println("Coloque um número de 1 a 100");
        Integer numero2 = sorte.nextInt();

        Integer vali = 1;
        while (vali <= 200) {
            if (numero2 < 1 || numero2 > 100) {
                System.out.println("Número incorreto");
                numero2 = sorte.nextInt();
            } else {
                vali++;
                Integer numero = ThreadLocalRandom.current().nextInt(0, 101);
                
                if (numero == numero2 && sorteio == 0) {
                    sorteio = vali;
                }
                
                if (numero % 2 == 0) {
                    par++;
                }
                else{
                    impar++;
                }
            }
        }
        
        if (sorteio == 0) {
            System.out.printf("Seu número não foi sorteado!\n"
                    + "Foram sorteados %d pares e %d impares\n", par, impar);
        }
        else{
            System.out.printf("Seu número foi sorteado pela 1ª vez %d\n"
                    + "Foram sorteados %d pares e %d impares\n", sorteio, 
                    par, impar);
        }

    }

}
