
import java.util.Scanner;


public class Expoente {
    
    public static void main(String[] args) {
        
        Scanner calculo = new Scanner(System.in);
        
        System.out.println("Entre com a base");
        Integer base = calculo.nextInt();
        
        System.out.println("Entre com o expoente");
        Integer expo = calculo.nextInt();
        
        Integer resultado = 1;
        
        
        if (expo == 0) {
            resultado = 1;
        }
        else{
            for (int i = 1; i <= expo; i++) {
                resultado = resultado * base;
            }
        }
        System.out.printf("%d elevado a %d é %d", base, expo, resultado);
    }
    
}
