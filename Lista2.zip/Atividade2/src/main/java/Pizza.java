
import java.util.Scanner;

public class Pizza {

    public static void main(String[] args) {

        Scanner pizza = new Scanner(System.in);

        Integer mussarela = 0;
        Integer quatroQueijos = 0;
        Integer calabresa = 0;

        Integer voto = 10;

        Integer v = 1;
        while (v <= voto) {
            System.out.println("Vote em seu sabor favorito:");
            Integer votos = pizza.nextInt();

            if (votos != 5 && votos != 25 && votos != 50) {
                System.out.println("Voto incorreto");
            } else {
                v++;
                switch (votos) {
                    case 5:
                        mussarela++;
                        break;
                    case 25:
                        calabresa++;
                        break;
                    case 50:
                        quatroQueijos++;
                        break;
                    default:
                        break;
                }
            }
        }

        String vencedor = null;

        if (mussarela > calabresa && mussarela > quatroQueijos) {
            vencedor = "Mussarela";
        } else if (calabresa > mussarela && calabresa > quatroQueijos) {
            vencedor = "Calabresa";
        } else if (quatroQueijos > mussarela && quatroQueijos > calabresa) {
            vencedor = "Quatro Queijos";
        }

        System.out.printf("Mussarela recebeu %d votos\n"
                + "Calabresa recebeu %d votos\n"
                + "Quatro queijos recebeu %d votos\n"
                + "O vencedor foi %s\n", mussarela, calabresa, quatroQueijos,
                vencedor);

    }

}
