
import java.util.Scanner;


public class NúmerosPares {
    
    public static void main(String[] args) {
        
        Scanner par = new Scanner(System.in);
        
        Integer pares = 0;
        while (pares <= 40) {            
            if (pares % 2 == 0) {
                System.out.println(pares);
            }
            pares++;
        }
        
    }
    
}
