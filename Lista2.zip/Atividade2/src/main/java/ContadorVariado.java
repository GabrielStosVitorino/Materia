
public class ContadorVariado {

    public static void main(String[] args) {

        for (double i = 0.15; i <= 5; i += 0.15) {
            System.out.printf("%.2f\n", i);
        }

    }

}
