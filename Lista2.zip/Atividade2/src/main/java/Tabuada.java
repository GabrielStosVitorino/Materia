
import java.util.Scanner;

public class Tabuada {

    public static void main(String[] args) {

        Scanner tabuada = new Scanner(System.in);

        System.out.println("Digite um número");
        Integer numero = tabuada.nextInt();

        System.out.println("Tabuada do " + numero + ":\n");
        for (int i = 0; i <= 10; i++) {
            System.out.println(numero + " X " + i + " = " + (numero * i));

        }

    }
}
