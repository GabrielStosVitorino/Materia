
import java.util.Scanner;


public class Login {
    
    public static void main(String[] args) {
        
        Scanner log = new Scanner(System.in);
        
        System.out.println("Usuário");
        String login = log.next();
        
        System.out.println("Senha");
        String senha = log.next();
        
        while (!"admin".equals(login) && !"#Bandtec".equals(senha)) {            
            System.out.println("Login ou senha inválidos");
            
            System.out.println("Login");
            login = log.next();
            
            System.out.println("Senha");
            senha = log.next();
        }
        
        System.out.println("Login bem sucedido");
        
    }
    
}
