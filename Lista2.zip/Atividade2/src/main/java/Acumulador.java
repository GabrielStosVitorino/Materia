
import java.util.Scanner;

public class Acumulador {

    public static void main(String[] args) {

        Scanner acumula = new Scanner(System.in);

        System.out.println("Digita ai");
        Integer numero = acumula.nextInt();

        Integer soma = 0;

        do {
            soma += numero;
            numero = acumula.nextInt();
        } while (numero != 0);

        System.out.printf("A soma dos números digitados foram %d", soma);
    }
}
