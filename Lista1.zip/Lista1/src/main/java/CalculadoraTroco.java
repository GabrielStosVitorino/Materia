
import java.util.Scanner;

public class CalculadoraTroco {

    public static void main(String[] args) {

        Scanner caixa = new Scanner(System.in);
        
        System.out.println("Coloque o valor do produto");
        Double valor = caixa.nextDouble();
        
        System.out.println("Quantas unidades foram compradas?");
        Integer unidade = caixa.nextInt();
        
        System.out.println("Qual foi o valor pago pelo cliente?");
        Double pagar = caixa.nextDouble();
        
        
        Double total = pagar - (unidade * valor);
        
        
        System.out.printf("Seu troco será de R$ %.2f", total);

    }

}
