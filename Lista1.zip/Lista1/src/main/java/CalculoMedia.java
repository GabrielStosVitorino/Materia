
import java.util.Scanner;

public class CalculoMedia {

    public static void main(String[] args) {

        Scanner escola = new Scanner(System.in);

        System.out.println("Coloque seu nome:");
        String nome = escola.next();

        System.out.println("Coloque sua 1ª nota:");
        Double nota1 = escola.nextDouble();

        System.out.println("Coloque sua 2ª nota:");
        Double nota2 = escola.nextDouble();

        Double media = (nota1 + nota2) / 2;

        System.out.printf("Olá, %s. Sua média foi de %.1f", nome, media);
    }

}
