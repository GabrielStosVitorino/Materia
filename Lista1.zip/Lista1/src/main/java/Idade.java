
import java.util.Scanner;


public class Idade {
    
    public static void main(String[] args) {
        
        Scanner anos = new Scanner(System.in);
        
        System.out.println("Digite seu nome:");
        String nome = anos.next();
        
        System.out.printf("Olá, %s! Qual o ano de seu nascimento?\n", nome);
        Integer ano = anos.nextInt();
        
        Integer media = 2030 - ano;
        
        System.out.printf("Em 2030 você terá %d anos\n", media);
        
    }
    
}
