
import java.util.Scanner;

public class Calculadora {

    public static void main(String[] args) {

        Scanner leitura = new Scanner(System.in);

        System.out.println("Coloque um número: ");
        Double numero = leitura.nextDouble();

        System.out.println("Coloque outro número: ");
        Double numero2 = leitura.nextDouble();

        Double soma = numero + numero2;
        Double sub = numero - numero2;
        Double multi = numero * numero2;
        Double divi = numero / numero2;

        System.out.printf("Resultado da soma:\n %.1f\n", soma);
        System.out.printf("Resultado da subtração: \n %.1f\n", sub);
        System.out.printf("Resultado da multiplicação:\n %.1f\n", multi);
        System.out.printf("Resultado da divisão:\n %.1f\n", divi);
    }

}
