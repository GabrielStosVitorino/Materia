
import java.util.Scanner;

public class Chico {

    public static void main(String[] args) {

        Scanner chi = new Scanner(System.in);

        Integer calo = 12;
        Integer calo2 = 20;
        Integer calo3 = 25;

        System.out.println("Quanto tempo você passou se aquecendo? PS: Coloque "
                + "o tempo em minutos");
        Integer tempo = chi.nextInt();

        System.out.println("Quanto tempo você praticou exercícios aeróbicos? "
                + "PS: Coloque o tempo em minutos");
        Integer tempo2 = chi.nextInt();

        System.out.println("Quanto tempo você praticou exercícios de musculação?"
                + " PS: Coloque o tempo em minutos");
        Integer tempo3 = chi.nextInt();

        Integer totalmin = tempo + tempo2 + tempo3;
        Integer totalcalo = (tempo * calo) + (tempo2 * calo2) + (tempo3 * calo3);

        System.out.printf("Olá, Jorge. Você fez um total de %d minutos de "
                + "exercícios e perdeu cerca de %d calorias",
                totalmin, totalcalo);
    }

}
