
import java.util.Scanner;

public class CadastroUsuario {

    public static void main(String[] args) {

        Scanner log = new Scanner(System.in);

        System.out.println("Insira seu login");
        String login = log.next();

        System.out.println("Insira sua senha");
        String senha = log.next();

        System.out.println("Quantas vezes deseja errar a senha antes do "
                + "bloqueio");
        Integer erro = log.nextInt();

        System.out.printf("Seu login é %s e sua senha é %s. "
                + "Você tem %d tentativas antes de ser bloqueado", login, senha,
                erro);

    }

}
