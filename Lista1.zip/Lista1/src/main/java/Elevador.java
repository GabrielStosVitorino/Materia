
import java.util.Scanner;

public class Elevador {

    public static void main(String[] args) {

        Scanner eleva = new Scanner(System.in);

        System.out.println("Coloque o limite de peso no elevador:");
        Double peso = eleva.nextDouble();

        System.out.println("Coloque o limite de pessoas no elevador:");
        Integer pessoas = eleva.nextInt();

        System.out.println("Coloque o peso da 1ª pessoa:");
        Double pessoa1 = eleva.nextDouble();

        System.out.println("Coloque o peso da 2ª pessoa:");
        Double pessoa2 = eleva.nextDouble();

        System.out.println("Coloque o peso da 3ª pessoa:");
        Double pessoa3 = eleva.nextDouble();
        
        Double total = pessoa1 + pessoa2 + pessoa3;

        System.out.printf("Entraram 3 pessoas no elevador, no qual cabem %d "
                + "pessoas.\nO peso total no elevador é de %.2f, "
                + "sendo que ele suporta %.2f\n", pessoas, total, peso);
    }

}
