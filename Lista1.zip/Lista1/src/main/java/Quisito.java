
import java.util.Scanner;

public class Quisito {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        Double filhos = 21.12;
        Double filhos2 = 15.88;
        Double filho3 = 12.44;

        System.out.println("Quantos filhos de 0 a 3 anos você possui?");
        Integer escolha = leitor.nextInt();

        System.out.println("Quantos filhos de 4 a 16 anos você possui?");
        Integer escolha2 = leitor.nextInt();

        System.out.println("Quantos filhos de 17 e 18 anos você possui?");
        Integer escolha3 = leitor.nextInt();

        Integer total = escolha + escolha2 + escolha3;

        Double bolsa = (filhos * escolha) + (filhos2 * escolha2)
                + (filho3 * escolha3);

        System.out.printf("Você tem um total de %d filhos e vai receber"
                + " R$%.2f de bolsa", total, bolsa);
    }

}
