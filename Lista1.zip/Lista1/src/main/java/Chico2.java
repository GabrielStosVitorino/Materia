
import java.util.Scanner;

public class Chico2 {

    public static void main(String[] args) {

        Scanner chico = new Scanner(System.in);

        System.out.println("Coloque seu salário bruto:");
        Double salario = chico.nextDouble();

        System.out.println("Qual o custo das passagens diárias, apenas ida:");
        Double passagem = chico.nextDouble();

        Double inss = salario * 0.10;
        Double ir = salario * 0.20;
        Double vt = passagem * 2 * 22;
        Double desconto = inss + ir + vt;
        Double liquido = salario - desconto;

        System.out.printf("Seu salário bruto é R$ %.2f, tem um total de R$ %.2f"
                + " em descontos e receberá um líquido de R$ %.2f", salario,
                desconto, liquido);
    }

}
